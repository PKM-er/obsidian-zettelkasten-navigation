## Source from
- German: [ZK II Zettel 9/8 - Niklas Luhmann-Archiv (niklas-luhmann-archiv.de)](https://niklas-luhmann-archiv.de/bestand/zettelkasten/zettel/ZK_2_NB_9-8_V)
- English translation: [English Translation of All Notes on Zettelkasten by Luhmann • Zettelkasten Method](https://zettelkasten.de/posts/luhmanns-zettel-translated/)
- Chinese translation: [（翻译）卢曼关于卡片盒的卡片 | 笔记系统？方法论？ (functoreality.github.io)](https://functoreality.github.io/blog-pkm/contents/%EF%BC%88%E7%BF%BB%E8%AF%91%EF%BC%89%E5%8D%A2%E6%9B%BC%E5%85%B3%E4%BA%8E%E5%8D%A1%E7%89%87%E7%9B%92%E7%9A%84%E5%8D%A1%E7%89%87/)




